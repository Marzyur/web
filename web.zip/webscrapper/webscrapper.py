import requests
from bs4 import BeautifulSoup
import pandas as pd
import time

# Read the website URLs from the input Excel file
df = pd.read_excel("C:\\api\html\webscrapper\excelfolder\Web Scraping Assignment.xlsx")
websites = df['WEBSITE'].tolist()

# Create an empty list to store the addresses
addresses = []

# Loop through the websites and extract the addresses
for website in websites:
    try:
        response = requests.get(website,timeout=5)
        soup = BeautifulSoup(response.content, 'html.parser')
        address = soup.find("div", {"class": "address"})
        if address:
            addresses.append(address.text)
        else:
            addresses.append("------")
    except :
        addresses.append("")
time.sleep(1)
# Write the addresses to the output Excel file
df['address'] = addresses
df.to_excel("C:\\api\html\webscrapper\Web.xlsx", index=False)
